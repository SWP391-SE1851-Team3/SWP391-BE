package com.team_3.School_Medical_Management_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolMedicalManagementSystemApplicationTests {

	@Test
	void contextLoads() {

	}

}
