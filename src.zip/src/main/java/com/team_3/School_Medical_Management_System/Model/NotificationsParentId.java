package com.team_3.School_Medical_Management_System.Model;

import java.io.Serializable;

public class NotificationsParentId implements Serializable {

    private String parentID;
    private int notificationId;
}
